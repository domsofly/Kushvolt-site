import { Container, ShieldCheck, Globe, Truck, ClipboardCheck, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const values = [
  {
    icon: Container,
    title: "Stock-Holding Hub",
    description: "Physical inventory in Jebel Ali Free Zone. No virtual stock, no factory lead times for stocked items.",
  },
  {
    icon: Truck,
    title: "Export Logistics",
    description: "Container loading, customs documentation, and freight coordination handled end-to-end.",
  },
  {
    icon: ShieldCheck,
    title: "Quality Certified",
    description: "All equipment comes with manufacturer warranties, certifications, and pre-shipment inspection.",
  },
  {
    icon: Globe,
    title: "MEA Specialists",
    description: "Deep expertise in Middle East and Africa markets with local compliance knowledge.",
  },
  {
    icon: ClipboardCheck,
    title: "Flexible Terms",
    description: "Letter of Credit, T/T, and project-based payment structures for qualified buyers.",
  },
  {
    icon: Users,
    title: "B2B Focus",
    description: "We serve EPC contractors, distributors, NGOs, and commercial buyers—not retail.",
  },
];

const AboutSection = () => {
  return (
    <section id="about" className="py-20 lg:py-32 bg-background relative">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Text Content */}
          <div>
            <span className="text-sm font-medium text-primary uppercase tracking-wider mb-4 block">
              About KushVolt
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
              Your Supply Chain{" "}
              <span className="text-gradient-solar">Partner</span>
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              KushVolt is not a retailer. We are a logistics and supply-chain partner for commercial solar buyers across the Middle East and Africa.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Operating from our strategically located warehouse in Dubai's Jebel Ali Free Zone, we maintain physical stock of Tier-1 solar equipment ready for immediate export. Our focus is on container-scale orders for EPC contractors, distributors, NGOs, factories, farms, and cloud kitchens.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8">
              <div>
                <div className="text-3xl font-bold text-gradient-solar">20+</div>
                <div className="text-sm text-muted-foreground">Countries Served</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-gradient-solar">500+</div>
                <div className="text-sm text-muted-foreground">Containers Shipped</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-gradient-solar">48h</div>
                <div className="text-sm text-muted-foreground">Dispatch Time</div>
              </div>
            </div>
          </div>

          {/* Values Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {values.map((value, index) => (
              <Card
                key={value.title}
                variant="trust"
                className="animate-fade-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-5">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <value.icon className="w-5 h-5 text-primary" />
                  </div>
                  <h4 className="font-semibold text-foreground mb-2">
                    {value.title}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
