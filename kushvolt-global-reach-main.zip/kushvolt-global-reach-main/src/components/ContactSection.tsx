import { MessageCircle, Mail, Phone, MapPin, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const ContactSection = () => {
  return (
    <section id="contact" className="py-20 lg:py-32 bg-gradient-to-b from-secondary/20 to-background relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl pointer-events-none" />

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-medium text-primary uppercase tracking-wider mb-4 block">
            Get In Touch
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
            Ready to{" "}
            <span className="text-gradient-solar">Order?</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Contact our commercial team for pricing, availability, and custom quotes. We respond within 24 hours.
          </p>
        </div>

        {/* Contact Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card variant="product" className="text-center">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-xl bg-[hsl(142,70%,49%)]/20 flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-6 h-6 text-[hsl(142,70%,49%)]" />
              </div>
              <h4 className="font-semibold text-foreground mb-2">WhatsApp</h4>
              <p className="text-sm text-muted-foreground mb-4">Fastest response</p>
              <Button variant="whatsapp" size="sm" className="w-full">
                Chat Now
              </Button>
            </CardContent>
          </Card>

          <Card variant="product" className="text-center">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Mail className="w-6 h-6 text-primary" />
              </div>
              <h4 className="font-semibold text-foreground mb-2">Email</h4>
              <p className="text-sm text-muted-foreground mb-4">sales@kushvolt.com</p>
              <Button variant="enterprise" size="sm" className="w-full">
                Send Email
              </Button>
            </CardContent>
          </Card>

          <Card variant="product" className="text-center">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Phone className="w-6 h-6 text-primary" />
              </div>
              <h4 className="font-semibold text-foreground mb-2">Phone</h4>
              <p className="text-sm text-muted-foreground mb-4">+971 4 XXX XXXX</p>
              <Button variant="enterprise" size="sm" className="w-full">
                Call Us
              </Button>
            </CardContent>
          </Card>

          <Card variant="product" className="text-center">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-6 h-6 text-primary" />
              </div>
              <h4 className="font-semibold text-foreground mb-2">Location</h4>
              <p className="text-sm text-muted-foreground mb-4">Jebel Ali, Dubai, UAE</p>
              <Button variant="enterprise" size="sm" className="w-full">
                View Map
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Main CTA */}
        <Card variant="elevated" glow className="max-w-4xl mx-auto overflow-hidden">
          <CardContent className="p-8 lg:p-12">
            <div className="flex flex-col lg:flex-row items-center gap-8">
              <div className="flex-1 text-center lg:text-left">
                <h3 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
                  Request a Custom Quote
                </h3>
                <p className="text-muted-foreground">
                  Tell us about your project requirements—system size, equipment preferences, delivery location—and we'll prepare a detailed proposal within 48 hours.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button variant="solar" size="xl">
                  Request Quote
                  <ArrowRight className="w-5 h-5" />
                </Button>
                <Button variant="outline" size="xl">
                  Download Catalog
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* B2B Notice */}
        <p className="text-center text-sm text-muted-foreground mt-8">
          Commercial inquiries only. We do not sell single panels or residential kits. Minimum order applies.
        </p>
      </div>
    </section>
  );
};

export default ContactSection;
