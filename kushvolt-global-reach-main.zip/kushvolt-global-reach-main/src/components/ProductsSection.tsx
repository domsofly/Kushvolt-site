import { Sun, Zap, Battery, BatteryCharging, Info } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const products = [
  {
    id: "panels",
    category: "Solar Panels",
    icon: Sun,
    description: "Tier-1 monocrystalline and bifacial modules from leading manufacturers.",
    brands: ["JinkoSolar", "Longi", "Canadian Solar"],
    specs: ["400W - 700W", "Mono PERC & TOPCon", "Bifacial Available"],
    inStock: true,
  },
  {
    id: "inverters",
    category: "Inverters",
    icon: Zap,
    description: "Grid-tied, hybrid, and off-grid inverters for all system sizes.",
    brands: ["GoodWe", "Growatt", "Sungrow"],
    specs: ["3kW - 250kW", "String & Central", "Hybrid Options"],
    inStock: true,
  },
  {
    id: "batteries",
    category: "Battery Storage",
    icon: Battery,
    description: "LFP and lithium battery systems for residential and commercial backup.",
    brands: ["Pylontech", "CATL", "BYD"],
    specs: ["5kWh - 500kWh", "LFP Technology", "Rack & Cabinet"],
    inStock: true,
  },
  {
    id: "power-stations",
    category: "Power Stations",
    icon: BatteryCharging,
    description: "Portable and industrial power stations for off-grid applications.",
    brands: ["EcoFlow", "Bluetti", "Custom Solutions"],
    specs: ["1kWh - 50kWh", "Portable & Fixed", "Generator Integration"],
    inStock: true,
  },
];

const ProductsSection = () => {
  return (
    <section id="products" className="py-20 lg:py-32 bg-gradient-to-b from-background to-secondary/20 relative">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-medium text-primary uppercase tracking-wider mb-4 block">
            Product Catalog
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
            Equipment{" "}
            <span className="text-gradient-solar">In Stock Now</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            All products are physically warehoused in Dubai and available for immediate container loading. Pricing available upon request.
          </p>
        </div>

        {/* Product Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <Card
              key={product.id}
              variant="product"
              className="animate-fade-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader>
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <product.icon className="w-6 h-6 text-primary" />
                  </div>
                  {product.inStock && (
                    <Badge variant="outline" className="text-xs border-primary/30 text-primary">
                      In Stock
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-lg">{product.category}</CardTitle>
                <CardDescription className="text-sm">
                  {product.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Brands */}
                <div>
                  <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Brands
                  </span>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {product.brands.map((brand) => (
                      <span
                        key={brand}
                        className="text-xs px-2 py-1 rounded bg-secondary text-secondary-foreground"
                      >
                        {brand}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Specs */}
                <div>
                  <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Specifications
                  </span>
                  <ul className="mt-2 space-y-1">
                    {product.specs.map((spec) => (
                      <li key={spec} className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <div className="w-1 h-1 rounded-full bg-primary" />
                        {spec}
                      </li>
                    ))}
                  </ul>
                </div>

                <Button variant="enterprise" size="sm" className="w-full mt-4">
                  Request Quote
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Custom Orders Notice */}
        <Card variant="trust" className="mt-12 max-w-3xl mx-auto">
          <CardContent className="flex items-start gap-4 p-6">
            <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
              <Info className="w-5 h-5 text-accent" />
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-1">
                Custom & Made-to-Order Equipment
              </h4>
              <p className="text-sm text-muted-foreground">
                Need specific configurations, rare models, or bulk orders beyond our current stock? We source directly from manufacturers with competitive lead times. Contact us for a custom quote.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default ProductsSection;
