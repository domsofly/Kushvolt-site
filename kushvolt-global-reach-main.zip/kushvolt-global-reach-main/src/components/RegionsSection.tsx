import { ArrowRight, Sun, Zap, Battery, Grid3X3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import regionMea from "@/assets/region-mea.jpg";
import regionAfrica from "@/assets/region-africa.jpg";

const regions = [
  {
    id: "middle-east",
    title: "Middle East",
    subtitle: "Utility-Scale & Grid-Tied",
    description: "High-voltage systems for large-scale solar farms, industrial facilities, and commercial installations. Designed for grid integration and maximum ROI.",
    image: regionMea,
    features: [
      { icon: Grid3X3, label: "Utility-Scale Systems" },
      { icon: Zap, label: "High-Voltage Solutions" },
      { icon: Sun, label: "Grid-Tied Inverters" },
    ],
    cta: "Explore MEA Solutions",
  },
  {
    id: "africa",
    title: "Africa",
    subtitle: "Hybrid & Off-Grid",
    description: "Reliable backup power and hybrid systems for areas with unstable grids. Generator-ready configurations for factories, farms, and NGO installations.",
    image: regionAfrica,
    features: [
      { icon: Battery, label: "Battery Storage" },
      { icon: Zap, label: "Hybrid Inverters" },
      { icon: Sun, label: "Off-Grid Ready" },
    ],
    cta: "Explore Africa Solutions",
  },
];

const RegionsSection = () => {
  return (
    <section id="regions" className="py-20 lg:py-32 bg-background relative">
      {/* Section Header */}
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-medium text-primary uppercase tracking-wider mb-4 block">
            Regional Focus
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
            Solutions for{" "}
            <span className="text-gradient-solar">Every Market</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Whether you're building utility-scale solar farms in the Gulf or deploying hybrid systems across Africa, we have the right equipment in stock.
          </p>
        </div>

        {/* Region Cards */}
        <div className="grid lg:grid-cols-2 gap-8">
          {regions.map((region, index) => (
            <Card
              key={region.id}
              variant="region"
              className="group overflow-hidden animate-fade-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Image */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={region.image}
                  alt={region.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
              </div>

              <CardHeader className="relative -mt-12 z-10">
                <span className="text-xs font-medium text-primary uppercase tracking-wider">
                  {region.subtitle}
                </span>
                <CardTitle className="text-2xl lg:text-3xl text-foreground">
                  {region.title}
                </CardTitle>
              </CardHeader>

              <CardContent className="space-y-6">
                <CardDescription className="text-base leading-relaxed">
                  {region.description}
                </CardDescription>

                {/* Features */}
                <div className="flex flex-wrap gap-3">
                  {region.features.map((feature) => (
                    <div
                      key={feature.label}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary/50 text-sm text-muted-foreground"
                    >
                      <feature.icon className="w-4 h-4 text-primary" />
                      <span>{feature.label}</span>
                    </div>
                  ))}
                </div>

                <Button variant="enterprise" className="w-full mt-4">
                  {region.cta}
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RegionsSection;
